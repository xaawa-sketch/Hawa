HAWA ACADEMY — CERTIFICATE VERIFICATION PAGE
=============================================

Files:
- index.html: responsive certificate verification page.
- It currently contains a demo record for:
  Farxaan Ali Abdi
  Computer Application
  Serial: HA-CA-2026-1025-FA01
  Start: 7 September 2026
  Completion: 25 October 2026

IMPORTANT:
This is a static demo page. The record is stored in the page's JavaScript, so it is not tamper-proof and should not be described as a secure official registry until it is deployed and the records are managed securely. It also does not yet have a live public URL, so the certificate QR code cannot be connected to it yet.

FREE HOSTING OPTION (GitHub Pages):
1. Create/sign in to a GitHub account.
2. Create a public repository named: hawa-academy-verification
3. Upload index.html from this folder to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. GitHub will show the public website URL once deployment completes.
7. Open that URL on a phone to test it.

QR CODE:
After the page is online, make the QR code point to:
YOUR_LIVE_SITE_URL/?serial=HA-CA-2026-1025-FA01
Replace YOUR_LIVE_SITE_URL with the exact URL GitHub Pages provides. Do not print the QR code until this URL is live and tested.

For a more secure system, move certificate records to a server/database and restrict who can add or edit records.
